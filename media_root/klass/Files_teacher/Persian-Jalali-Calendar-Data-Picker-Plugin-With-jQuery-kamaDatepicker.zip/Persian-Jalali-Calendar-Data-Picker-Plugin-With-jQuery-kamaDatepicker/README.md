# kamaDatepicker
A jQuery based datepicker for jalali (shamsi) calendar. <a href="http://www.jqueryscript.net/demo/Persian-Jalali-Calendar-Data-Picker-Plugin-With-jQuery-kamaDatepicker/" target="_blank">Demo</a>
